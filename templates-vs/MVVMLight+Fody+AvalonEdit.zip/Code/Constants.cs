﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Code
{
    public static class Constants
    {
        public static class Resources
        {
            // TODO: find a t4 template to generate this from contents of "Resource" folder
            public const string SyntaxXshd = "$safeprojectname$.Resources.syntax.xshd";
        }
    }
}
