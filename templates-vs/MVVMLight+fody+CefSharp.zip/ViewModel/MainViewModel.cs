﻿using GalaSoft.MvvmLight;

namespace $safeprojectname$.ViewModel
{
    public class MainViewModel : ViewModelBase
    {
        public string WelcomeTitle { get; set; } = "MVVM test app";

        public MainViewModel()
        {
        }
    }
}