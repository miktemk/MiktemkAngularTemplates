﻿using CefSharp;
using Miktemk;
using Newtonsoft.Json;
using $safeprojectname$.ViewModel;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace $safeprojectname$.Controls
{
    /// <summary>
    /// Interaction logic for WebViewJasarUIControl.xaml
    /// </summary>
    public partial class WebViewJasarUI : UserControl, IScsIdeExinvoker
    {
        public WebViewJasarUI()
        {
            InitializeComponent();
            Browser.RegisterAsyncJsObject("exinvoker", this as IScsIdeExinvoker, BindingOptions.DefaultBinder);
        }

        private void Browser_IsBrowserInitializedChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Browser.IsBrowserInitialized)
            {
                Browser.Load("local://mywebview/index.html");
            }
        }

        #region -------------------------------- DP: VisualizationVM -----------------------------------

        public VisualizationVM VisualizationModel
        {
            get { return (VisualizationVM)GetValue(VisualizationModelProperty); }
            set { SetValue(VisualizationModelProperty, value); }
        }

        // Using a DependencyProperty as the backing store for VisualizationModel.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty VisualizationModelProperty =
            DependencyProperty.Register("VisualizationModel", typeof(VisualizationVM), typeof(WebViewJasarUI),
                        new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender, OnVisualizationModelPropertyChanged));

        private static void OnVisualizationModelPropertyChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            var control = sender as WebViewJasarUI;
            if (control != null)
                control.OnVisualizationModelChanged((VisualizationVM)e.OldValue, (VisualizationVM)e.NewValue);
        }

        private void OnVisualizationModelChanged(VisualizationVM oldValue, VisualizationVM newValue)
        {
            if (!Browser.IsBrowserInitialized)
                return;
            if (newValue == null)
                newValue = new VisualizationVM { ViewType = VisualizationType.None };

            var vizJson = JsonUtils.JsonSerialize(newValue);
            Browser.GetMainFrame().ExecuteJavaScriptAsync($"exinvoke_setVisualizationVM({vizJson})");
        }

        #endregion

        //#region ------------------------------ exop ---------------------------------

        // TODO: use snippet: propdpexopcommand

        //#endregion

    }

    public interface IScsIdeInvoker
    {
        void setVisualizationVM(VisualizationVM vm);
    }
    public interface IScsIdeExinvoker
    {
        // TODO: add methdos that Angular will be calling
    }

}
