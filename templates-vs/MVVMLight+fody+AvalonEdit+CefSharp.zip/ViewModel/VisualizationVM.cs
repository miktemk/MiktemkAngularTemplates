﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.ViewModel
{
    public enum VisualizationType
    {
        None,
        CaretPositionChanged,
        BuildResults
    }
    public class VisualizationVM
    {
        public VisualizationType ViewType { get; set; }
        public string DebugText { get; set; }
    }
}
