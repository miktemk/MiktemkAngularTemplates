﻿using NDesk.Options;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    class Program
    {
        // TODO: abc123: fix the usage string
        private const string UsageString = "Usage: thing.exe --from blah --to bleh [OPTIONS] dir";

        static void Main(string[] args)
        {
            new Program(args);
        }

        //=====================================================================================================

        private OptionSet ndeskOptions;
        private bool isDryRun = false;
        private bool isVerbose = false;
        private bool showHelp = false;

        public Program(string[] args)
        {
            //isDryRun = true;
            //isVerbose = true;

            ndeskOptions = new OptionSet
            {
                {
                    "d|dry-run",
                    "Do not make any changes, just tell me what you will do",
                    x => isDryRun = (x != null)
                },
                {
                    "v|verbose",
                    "Output everything that is happening",
                    x => isVerbose = (x != null)
                },
                {
                    "h|help",
                    "Show help",
                    x => showHelp = (x != null)
                },
            };

            string arg1 = null;
            try
            {
                var extra = ndeskOptions.Parse(args);
                arg1 = extra.FirstOrDefault();
            }
            catch (OptionException e)
            {
                ShowHelp();
                return;
            }

            if (showHelp)
            {
                ShowHelp();
                return;
            }
            if (arg1 == null)
            {
                ShowHelp("ERROR: directory in which we will be doing this operation must be the last argument!");
                return;
            }

            DoWork(arg1);
        }

        private void DoWork(string arg1)
        {
            LogForce($"TODO: abc123: your custom code here to work in dir: {arg1}");
        }

        private void ShowHelp(string customMessage = null)
        {
            if (customMessage != null)
                LogForce(customMessage + "\n");
            LogForce(UsageString);
            ndeskOptions.WriteOptionDescriptions(Console.Out);
        }

        //---------------------------------- helpers --------------------------------------

        private void LogVerbose(string s)
        {
            if (!isVerbose)
                return;
            LogForce(s);
        }
        private void LogForce(string s)
        {
            Debug.WriteLine(s); // TODO: abc123: uncomment Console.WriteLine when app is ready
            //Console.WriteLine(s);
        }
    }
}
