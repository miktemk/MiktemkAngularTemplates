import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'eggsperimental-test1',
  templateUrl: './test1.component.html',
  styleUrls: ['./test1.component.less']
})
export class Test1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
