import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'eggsperimental-test2',
  templateUrl: './test2.component.html',
  styleUrls: ['./test2.component.less']
})
export class Test2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
