import { Pipe, PipeTransform } from '@angular/core';
import { ConversationMessageType } from '../../../core/models/conversation.vm';

@Pipe({
  name: 'cssPipeMessageType'
})
export class CssPipeSidebarMesasgeType implements PipeTransform {

  transform(value: any): any {
    if (value == ConversationMessageType.Agent)
      return 'agent';
    return 'user';
  }

}
