import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { YesNoPipe } from './yes-no.pipe';
import { ValidationFirstErrorPipe } from "./validation-errors.pipe";
import { IterablePipe } from './iterable.pipe';
import { CssPipeSidebarMesasgeType } from './css-sidebar-message-type.pipe';

@NgModule({
  imports: [
    CommonModule, // TODO: check if CommonModule import is needed
  ],
  exports: [
    ValidationFirstErrorPipe,
    YesNoPipe,
    IterablePipe,
    CssPipeSidebarMesasgeType,
  ],
  declarations: [
    ValidationFirstErrorPipe,
    YesNoPipe,
    IterablePipe,
    CssPipeSidebarMesasgeType,
  ],
  // providers: [
  //   DatePipe,
  // ]
})
export class MyPipesModule { }
