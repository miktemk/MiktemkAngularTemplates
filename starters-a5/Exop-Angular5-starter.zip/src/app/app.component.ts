import { Component } from '@angular/core';
import { ConversationVM, ConversationMessageVM, ConversationMessageType } from '../core/models/conversation.vm';
import { ExopService, VisualizationVM } from '../core/gen/exop';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'jasar-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less']
})
export class AppComponent {
  
  viz: VisualizationVM;

  private subscription_setVisualizationVM: Subscription;

  constructor(
    private exopUtils: ExopService,
  ) {}

  ngOnInit() {
    this.subscription_setVisualizationVM = this.exopUtils.setVisualizationVM.subscribe((viz:VisualizationVM) => this.setVisualizationVM(viz));
  }
  ngOnDestroy() {
    this.subscription_setVisualizationVM.unsubscribe();
  }

  setVisualizationVM(viz:VisualizationVM) {
    this.viz = viz;
  }
}


//TODO: move
export class NavLink {
  url: string;
  label: string;
  responsiveClass?: string[];
}
