import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { CommonComponentsModule } from './common-components/common-components.module';
import { AppRoutingModule } from './app-routing.module';
import { JasarCoreModule } from '../core/jasar-core.module';

@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule,
    JasarCoreModule,
    CommonComponentsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
