import { NgModule } from '@angular/core';
import { UIRouterModule, Ng2StateDeclaration, UIRouter, Category, Transition, TargetState } from "@uirouter/angular";
import { Visualizer } from '@uirouter/visualizer';

const routes: Ng2StateDeclaration[] = [
  // { name: 'test1', url: '/test1', component: Test1Component },
  // { name: 'test2', url: '/test2', component: Test2Component },
];


export function uiRouterConfigFn(uiRouter: UIRouter) {
  const transitionService = uiRouter.transitionService;
  // requiresAuthHook(transitionService);
  // requiresWhitelistHook(transitionService);
  
  //uiRouter.trace.enable(Category.TRANSITION);
  //uiRouter.trace.enable(Category.RESOLVE);
  // uiRouter.plugin(Visualizer);
}


@NgModule({
  imports: [
    UIRouterModule.forRoot({
      states: routes,
      useHash: true,
      //otherwise: { state: '' },
      config: uiRouterConfigFn
    })
  ],
  exports: [UIRouterModule]
})
export class AppRoutingModule { }
