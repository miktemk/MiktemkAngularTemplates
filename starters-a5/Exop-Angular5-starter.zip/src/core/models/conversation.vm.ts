export class ConversationVM {
  messages: ConversationMessageVM[];
  isWaitingResponse: boolean;
}

export enum ConversationMessageType {
  User,
  Agent
}

export class ConversationMessageVM {
  text: string;
  type: ConversationMessageType;
}

export class QueryBubbleVm {
  query: string;
  isInFocus: boolean;
}

