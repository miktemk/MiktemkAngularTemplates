import * as _ from 'lodash';
import { Injectable } from '@angular/core';
import { NgZone } from '@angular/core';
import { Subject } from 'rxjs/Subject';


//============================ enums ============================


export enum VisualizationType {
  None = 0,
  CaretPositionChanged = 1,
  BuildResults = 2,
}

//============================ classes ============================


/**
 * Source class: SmartCodeSearchIDE.ViewModel.VisualizationVM
 * TODO: endpointClass.ToDebugJson()
 */
export class VisualizationVM {
  ViewType: VisualizationType;
  DebugText: string;

  constructor(init?:Partial<VisualizationVM>) {
    Object.assign(this, init, {
      ViewType: isNaN(init.ViewType) ? VisualizationType[init.ViewType] : init.ViewType,
    });
  }
}


//========================================================================================

@Injectable()
export class ExopService {
  
  public readonly setVisualizationVM:Subject<VisualizationVM> = new Subject<VisualizationVM>();

  constructor(
    private ngZone: NgZone,
  ) {
    window['exinvoke_setVisualizationVM'] = (vm:VisualizationVM) => {
      this.ngZone.run(() => {
        vm = vm ? new VisualizationVM(vm) : null;
        this.setVisualizationVM.next(vm);
      });
    };
  }

  //--------------------------------------------------------------------------------------

  readonly exinvokerGlobalName:string = 'exinvoker';

  

}