import { NgModule } from '@angular/core';

import { ExopService } from './gen/exop';

@NgModule({
  imports: [],
  providers: [
    ExopService
  ],
})
export class JasarCoreModule { }
